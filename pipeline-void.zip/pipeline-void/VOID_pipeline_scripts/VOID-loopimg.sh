echo "" > images_list.octave
for image in `ls <PATH_TO_TMP_TIF>*.tif `
do
echo "normalize_16bit (\"$image\");" >> images_list.octave
done
octave images_list.octave
#echo octave images_list.octave
#more images_list.octave > saida
#pwd
rm images_list.octave
