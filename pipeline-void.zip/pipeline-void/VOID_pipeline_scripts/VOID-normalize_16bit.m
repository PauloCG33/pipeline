function normalize_16bit (imgfile)
i=imread(imgfile);
#a=30;
#b=30;
#c=30;
#kr=0.05;
#xr0=135;
#kg=0.05;
#xg0=115;
m=<MEAN_INTENSITY_LEVEL>; #fator de referencia para que todos tenham a mesma media
i=int16(i);
factor=65535./max(i(:));
i(:)=i(:)*factor;
#i_r=i(:,:,1);
#i_g=i(:,:,2);
#i_b=i(:,:,3);
#rm=sum(sum(i_r(:)))/length(i_r(:));
#gm=sum(sum(i_g(:)))/length(i_g(:));
#bm=sum(sum(i_b(:)))/length(i_b(:));
imean=sum(sum(i(:)))/length(i(:));
imult=m/imean;
#x=a/rm;
#y=b/gm;
#z=c/bm;
#disp(rm); mostrar rm
#disp(gm); mostrar gm
#i(:,:,1)=x*i(:,:,1);
#i(:,:,2)=y*i(:,:,2);
i=imult*i;

#i(:,:,1)=255./(1+exp(-kr*(i(:,:,1)-xr0)));
#i(:,:,2)=255./(1+exp(-kg*(i(:,:,2)-xg0)));
#i(:,:,2)=0;
#i(:,:,3)=0;
i=uint16(i);
#nomesaida = strcat(imgfile,"");
nomesaida = strcat(imgfile,"");
imwrite(i,nomesaida);
