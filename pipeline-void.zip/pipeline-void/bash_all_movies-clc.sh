python pipeline-3.0.py 5 hacat m01 local > hacat-m01/Calculations/log.clc
echo done hacat-m01

python pipeline-3.0.py 5 hacat m02 local > hacat-m02/Calculations/log.clc
echo done hacat-m02

python pipeline-3.0.py 5 hacat m03 local > hacat-m03/Calculations/log.clc
echo done hacat-m03

python pipeline-3.0.py 5 hacat m04 local > hacat-m04/Calculations/log.clc
echo done hacat-m04

python pipeline-3.0.py 5 hacat m05 local > hacat-m05/Calculations/log.clc
echo done hacat-m05


python pipeline-3.0.py 5 cal27 m01 local > cal27-m01/Calculations/log.clc
echo done cal27-m01

python pipeline-3.0.py 5 cal27 m02 local > cal27-m02/Calculations/log.clc
echo done cal27-m02

python pipeline-3.0.py 5 cal27 m03 local > cal27-m03/Calculations/log.clc
echo done cal27-m03


python pipeline-3.0.py 5 scc9 m01 local > scc9-m01/Calculations/log.clc
echo done scc9-m01

python pipeline-3.0.py 5 scc9 m02 local > scc9-m02/Calculations/log.clc
echo done scc9-m02

python pipeline-3.0.py 5 scc9 m03 local > scc9-m03/Calculations/log.clc
echo done scc9-m03


python pipeline-3.0.py 5 fibroblastos m01 local > fibroblastos-m01/Calculations/log.clc
echo done fibroblastos-m01
